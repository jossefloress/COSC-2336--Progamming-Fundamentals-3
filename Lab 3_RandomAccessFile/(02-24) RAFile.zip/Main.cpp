/******************
	RAFile
*******************/

#pragma warning (disable:4996)

#include <iostream>

using namespace std;

#include <stdlib.h>

#include "RAFile.h"

int main ()
	{
	RAFile		DB1;
	WCS_String	Str ("xxxx");

	DB1.Open (Str);
	DB1.Close ();

	system ("pause");
	return 0;
	}
