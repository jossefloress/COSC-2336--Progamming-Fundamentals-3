#include <iostream>

using namespace std;

#include <stdlib.h>

#include <WCS_Pointer.h>
#include <WCS_String.h>

#include "UB_Array.h"

class D
	{
	public:
		int		A;
	};

void Func (const UB_Array <int, char> &);

int main ()
	{
	UB_Array <int, char>		U1;
	UB_Array <WCS_String, D>	U2;

	U1 [4] = 'A';
	U1 [8] = 'B';
	U1 [2] = 'C';

	cout << U1 [2] << U1 [4] << U1 [8] << endl;

	Func (U1);

	system ("pause");
	return 0;
	}

void Func (const UB_Array <int, char> & U)
	{
	char	C1;

	cout << "Item number 2 is " << U [2] << endl;
	U.GetFirst (C1);
	cout << "First item is " << C1 << endl;
	}
