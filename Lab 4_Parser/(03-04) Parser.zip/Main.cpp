#pragma warning (disable:4996)

#include <stdlib.h>

#include "Token.h"

int main (int argc, char * argv [])
	{
	WCS_String Temp;
	Token Toke;

//	cout << "argv [0] is " << argv [0] << endl;
//	cout << "argv [1] is " << argv [1] << endl;
//	return 0;
	if (argc < 2)
			{
			cout << "Error, not enough command line arguments" << endl;
			return 0;
			}
		else
			Temp = argv [1];
	Token::OpenFile (Temp);
	do	{
		Toke.Build ();
		switch (Toke.GetType ())
			{
			case Token::KeywordEvalToken:
				cout << "Found Keyword EVAL" << endl;
				break;
			default:
				cout << "Should not get here" << endl;
			}
		} while (Toke.GetType () != Token::EndOfInputToken);
	Token::CloseFile ();
	system ("pause");
	return 0;
	}
