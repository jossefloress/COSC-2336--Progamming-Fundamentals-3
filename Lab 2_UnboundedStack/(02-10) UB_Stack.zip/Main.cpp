/******************
	
*******************/

#pragma warning (disable:4996)

#include <stdio.h>
#include <stdlib.h>

#include "UB_Stack.h"

int main ()
	{
	UB_Stack <char>		UBS;

	system ("pause");
	return 0;
	}
