#ifndef UB_ARRAY_H
#define UB_ARRAY_H

#include <WCS_Pointer.h>

//	the class used for INDEX below must support the comparison operators <  <=  ==  !=  >=  >

enum UB_Array_Exceptions	{
							ARRAY_OK,
							ArrayEmpty,
							IteratorNotInitialized,
							NodeNotFound,
							NoNextNode
							};

template <class INDEX, class DATA>
	class UB_Array
		{
		private:
			struct Node: public RefCount
				{
				INDEX				Index;
				DATA				Data;
				WCS_Pointer <Node>	pNext;
				WCS_Pointer <Node>	pPrev;

				Node	();
				Node	(const INDEX &);
				};
		public:
										UB_Array	();
										~UB_Array	();
					UB_Array_Exceptions	GetFirst	(DATA &) const;
					UB_Array_Exceptions	GetNext		(DATA &) const;
					UB_Array_Exceptions	Remove		(const INDEX &, DATA &);
					DATA &				operator []	(const INDEX &);
			const	DATA &				operator []	(const INDEX &) const;
		private:
										UB_Array	(const UB_Array <INDEX, DATA> &);

					WCS_Pointer <Node>		pHead;
					WCS_Pointer <Node>		pTail;
			mutable	WCS_Pointer <Node>		pCurrent;
					size_t					NumNodes;
		};

template <class INDEX, class DATA>
	UB_Array <INDEX, DATA>::Node::Node ()
		{
		}

template <class INDEX, class DATA>
	UB_Array <INDEX, DATA>::Node::Node (const INDEX & I)
		{
		Index	= I;
		}

template <class INDEX, class DATA>
	UB_Array <INDEX, DATA>::UB_Array (): NumNodes (0)
		{
		}

template <class INDEX, class DATA>
	UB_Array <INDEX, DATA>::~UB_Array ()
		{
		// Left as an exercise for the student
		}

template <class INDEX, class DATA>
	UB_Array_Exceptions UB_Array <INDEX, DATA>::GetFirst (DATA & D) const
		{
		if (!pHead)
				return ArrayEmpty;
			else
				{
				D			= (*pHead).Data;
				pCurrent	= pHead;
				return ARRAY_OK;
				}
		}

template <class INDEX, class DATA>
	UB_Array_Exceptions UB_Array <INDEX, DATA>::GetNext (DATA & D) const
		{
		if (!pHead)
				return ArrayEmpty;
			else
				if (!pCurrent)
						return IteratorNotInitialized;
					else
						if (!(*pCurrent).pNext)
								return NoNextNode;
							else
								{
								pCurrent	= (*pCurrent).pNext;
								D			= (*pCurrent).Data;
								return ARRAY_OK;
								}
		}

template <class INDEX, class DATA>
	UB_Array_Exceptions UB_Array <INDEX, DATA>::Remove (const INDEX &, DATA &)
		{
		// Left as an exercise for the student
		}

template <class INDEX, class DATA>
	DATA & UB_Array <INDEX, DATA>::operator [] (const INDEX & I)
		{
		WCS_Pointer <Node>	pTemp;

		if (!pHead)
				{
				pHead	= WCS_Pointer <Node> (new Node (I));
				pTail	= pHead;
				NumNodes++;
				return (*pHead).Data;
				}
			else
				if (I == (*pHead).Index)
						return (*pHead).Data;
					else
						if (I == (*pTail).Index)
								return (*pTail).Data;
							else
								if (I < (*pHead).Index)
										{
										pTemp			= WCS_Pointer <Node> (new Node (I));
										(*pHead).pPrev	= pTemp;
										(*pTemp).pNext	= pHead;
										pHead			= pTemp;
										NumNodes++;
										return (*pHead).Data;
										}
									else
										if (I > (*pTail).Index)
												{
												pTemp			= WCS_Pointer <Node> (new Node (I));
												(*pTail).pNext	= pTemp;
												(*pTemp).pPrev	= pTail;
												pTail			= pTemp;
												NumNodes++;
												return (*pTail).Data;
												}
											else
												{
												for (pTemp = (*pHead).pNext; I > (*pTemp).Index; pTemp = (*pTemp).pNext);
												if (I == (*pTemp).Index)
														return (*pTemp).Data;
													else
														{
														WCS_Pointer <Node>	pTemp2;

														pTemp2					= WCS_Pointer <Node> (new Node (I));
														(*pTemp2).pPrev			= (*pTemp).pPrev;
														(*(*pTemp).pPrev).pNext	= pTemp2;
														(*pTemp2).pNext			= pTemp;
														(*pTemp).pPrev			= pTemp2;
														NumNodes++;
														return (*pTemp2).Data;
														}
												}
		}

template <class INDEX, class DATA>
	const DATA & UB_Array <INDEX, DATA>::operator [] (const INDEX & I) const
		{
		WCS_Pointer <Node>	pTemp;

		if (!pHead)
				{
				// throw an exception
				throw -1;
				}
			else
				if (I == (*pHead).Index)
						return (*pHead).Data;
					else
						if (I == (*pTail).Index)
								return (*pTail).Data;
							else
								if (I < (*pHead).Index)
										{
										// throw an exception
										throw -1;
										}
									else
										if (I > (*pTail).Index)
												{
												// throw an exception
												throw -1;
												}
											else
												{
												for (pTemp = (*pHead).pNext; I > (*pTemp).Index; pTemp = (*pTemp).pNext);
												if (I == (*pTemp).Index)
														return (*pTemp).Data;
													else
														{
														// throw an exception
														throw -1;
														}
												}
		}

#endif
