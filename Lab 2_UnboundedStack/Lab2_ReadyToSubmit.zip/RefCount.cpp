#include "RefCount.h"

RefCount::RefCount (): References (0)
	{
	}

RefCount::~RefCount ()
	{
	}
